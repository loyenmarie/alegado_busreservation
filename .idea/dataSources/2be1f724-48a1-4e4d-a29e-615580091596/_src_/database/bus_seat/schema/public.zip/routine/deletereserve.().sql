create function deletereserve(OUT text, OUT text, OUT text, OUT text, OUT text, OUT text, OUT text, OUT integer, OUT text) returns SETOF record
LANGUAGE plpgsql
AS $$
DECLARE
    loc_res text;
  BEGIN
      TRUNCATE reservation;
  END;

$$;
