create function ssss(par_username text, par_password text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
		loc_username text;
		loc_password text;
    loc_res text;
    begin
			INSERT INTO reserve
          (name, email)
      VALUES (par_username,par_password);
      
      return loc_res;
	  END;


$$;
