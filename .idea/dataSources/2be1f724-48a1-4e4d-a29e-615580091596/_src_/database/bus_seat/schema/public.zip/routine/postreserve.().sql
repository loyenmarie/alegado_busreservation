create function postreserve(OUT text, OUT text, OUT text, OUT time without time zone, OUT text, OUT text, OUT integer, OUT text, OUT integer) returns SETOF record
LANGUAGE SQL
AS $$
select s.namee, s.email, s.dept_date, s.tiime, s.origin, s.destinationn, s.seat_noo, p.price, p.bus_id from reserve s, bus p;
$$;
