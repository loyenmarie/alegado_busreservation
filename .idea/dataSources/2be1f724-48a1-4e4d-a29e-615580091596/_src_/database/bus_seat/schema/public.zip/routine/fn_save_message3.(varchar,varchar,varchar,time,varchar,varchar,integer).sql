create function fn_save_message3(names character varying, emails character varying, dept_dates character varying, xtimes time without time zone, origins character varying, destinations character varying, seat_nos integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
  loc_res      TEXT;
BEGIN
   INSERT INTO reserve
          (name, email, dept_date, tiime, origin, destinationn, seat_noo)
      VALUES (names,emails,dept_dates,xtimes,origins,destinations,seat_nos);
     return name;
END;
$$;
