create function reserves(names text, emails text, dept_dates text, xtimes time without time zone, origins text, destinations text, seat_nos integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
    loc_res text;
  BEGIN
      INSERT INTO reservation
          (name, contact, deptdate, tiime, origin, destination, seat_no)
      VALUES (names,emails,dept_dates,xtimes,origins,destinations,seat_nos);
    loc_res = 'stored';
    return loc_res;
  END;

$$;
