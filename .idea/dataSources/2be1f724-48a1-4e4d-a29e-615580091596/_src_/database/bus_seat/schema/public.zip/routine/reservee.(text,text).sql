create function reservee(par_name text, par_email text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
		loc_name text;
    loc_email text;
		loc_ress text;
		--loc_dept_date date;
		--loc_tiime time;
		--loc_origin text;
		--loc_destinationn text;
		-- loc_seat_noo int;


    begin
			SELECT into loc_name, loc_email from reserve where name = par_name and email= par_email ;
		if loc_ress notnull then
      UPDATE reserve SET reservee = TRUE ;
			INSERT INTO reserve(name, email) VALUES (par_name, par_email);
        loc_ress = 'ok';
      else
					loc_ress = 'Error';
			end if;
			return loc_ress;
	  END;
$$;
