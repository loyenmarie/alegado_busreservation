create function reservation(par_name text, par_email text, par_depdate text, par_time text, par_origin text, par_destination text, par_seat_no text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
		loc_name text;
    loc_res text;

begin
			select into loc_name name from reservation where name = par_name;
			if loc_name isnull then

				insert into reservation (name, email, dep_date, time, origin, destination, seat_no) values (par_name, par_email, par_depdate,par_time, par_origin, par_destination, par_seat_no);
				loc_res = 'OK';

				else
				loc_res = 'ID EXISTED';
			END IF;
			return loc_res;
		END;

$$;
