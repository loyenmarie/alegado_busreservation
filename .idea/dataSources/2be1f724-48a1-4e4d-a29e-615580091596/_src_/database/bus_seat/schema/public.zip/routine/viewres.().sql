create function viewres(OUT text, OUT text, OUT text, OUT text, OUT text, OUT text, OUT text, OUT integer, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select a.name, a.contact, a.deptdate, a.tiime, a.origin, a.destination, a.seat_no, b.bus_no, b.price from reservation a, selectbus b ;
$$;
