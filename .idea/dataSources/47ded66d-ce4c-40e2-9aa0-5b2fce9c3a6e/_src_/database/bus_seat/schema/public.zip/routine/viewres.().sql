create function viewres(OUT text, OUT text, OUT text, OUT text, OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE SQL
AS $$
select a.name, a.contact, a.time, a.route, a.seat_no, a.bus_no, b.price_rate from reservation a, price b ;
$$;
