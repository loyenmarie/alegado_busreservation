create function reserves(names text, contacts text, times text, routes text, seat_nos text, bus_nos text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
    loc_res text;
  BEGIN
      INSERT INTO reservation
          (name, contact, time, route, seat_no, bus_no)
      VALUES (names,contacts,times,routes,seat_nos,bus_nos);
    loc_res = 'stored';
    return loc_res;
  END;

$$;
