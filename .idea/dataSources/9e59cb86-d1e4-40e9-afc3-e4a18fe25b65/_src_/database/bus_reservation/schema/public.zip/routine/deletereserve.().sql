create function deletereserve(OUT text, OUT text, OUT text, OUT text, OUT text, OUT text, OUT text) returns SETOF record
LANGUAGE plpgsql
AS $$
declare
    loc_name text;
    loc_contact text;
    loc_route text;
   loc_seat_no text;
   loc_bus_no text;
   loc_price_rate text;

  begin
      select into loc_name name, loc_contact contact,  loc_route route, loc_seat_no seat_no, loc_bus_no bus_no, loc_price_rate price_rate from reservation
      where loc_name NOTNULL and loc_contact NOTNULL and loc_route NOTNULL and loc_route NOTNULL and loc_seat_no NOTNULL and loc_bus_no NOTNULL;

      if loc_name NOTNULL and loc_contact NOTNULL and loc_route NOTNULL and loc_route NOTNULL and loc_seat_no NOTNULL and loc_bus_no NOTNULL then

      delete from reservation;
       insert into reservation(name,contact,time,route,seat_no,bus_no) values (' ',' ',' ',' ',' ',' ');
      ELSE
       insert into reservation(name,contact,time,route,seat_no,bus_no) values (' ',' ',' ',' ',' ',' ');
      END IF ;
  end;
$$;
