create function editedit(names text, contacts text, times text, routes text, seat_nos text, bus_nos text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

    loc_names text;
    loc_contacts text;
    loc_times text;
    loc_routes text;
    loc_seat_nos text;
    loc_bus_no text;

  begin
     select into loc_names name, loc_contacts contact , loc_times tiime, loc_routes route, loc_seat_nos seat_no, loc_bus_no bus_no from reservation;
    if loc_names NOTNULL then

      UPDATE reservation set name = names,  contact = contacts, tiime = times, route = routes, seat_no = seat_nos, bus_no = bus_nos where reserve_id = 1;
       loc_res = 'ok';

     else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
