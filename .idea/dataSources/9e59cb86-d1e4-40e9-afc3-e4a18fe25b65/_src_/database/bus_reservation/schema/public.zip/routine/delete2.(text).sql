create function delete2(par_del text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_res text;

  begin
     if par_del NOTNULL then
        delete from reservation;
         loc_res = 'ok';
      else
       loc_res = 'Error';
     end if;
     return loc_res;
  end;
$$;
