create function reservation(par_name text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
		loc_name text;
    loc_res text;

begin
			select into loc_name name from reservation where name = par_name;
			if loc_name isnull then

				insert into reservation (name) values (par_name);
				loc_res = 'OK';

				else
				loc_res = 'ID EXISTED';
			END IF;
			return loc_res;
		END;

$$;
