create function login(par_username text, par_password text) returns text
LANGUAGE plpgsql
AS $$
DECLARE
		loc_username text;
		loc_password text;
    loc_res text;
    begin
			SELECT into loc_username "username" , loc_password "password" from account where username = par_username and password = par_password ;
			if loc_username isnull and loc_password isnull THEN
						loc_res = 'Error Username or password';
			else
					loc_res =  'ok';
			end if;
			return loc_res;
	END;


$$;
