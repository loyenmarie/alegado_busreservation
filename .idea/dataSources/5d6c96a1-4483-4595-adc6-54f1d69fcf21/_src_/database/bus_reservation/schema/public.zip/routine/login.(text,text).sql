create function login(par_username text, par_password text) returns text
LANGUAGE plpgsql
AS $$
declare
    loc_username text;
    loc_password text;
    loc_res text;
  begin
     select into loc_username username from account where username = par_username;
     select into loc_password password from account where password = par_password;

     if loc_username isnull AND loc_password isnull then
       loc_res = 'Error';
     else
       loc_res = 'ok';
     end if;
     return loc_res;
  end;
$$;
